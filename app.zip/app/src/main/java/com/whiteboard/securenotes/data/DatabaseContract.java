package com.whiteboard.securenotes.data;

import android.provider.BaseColumns;

public class DatabaseContract {

    public static final class TableColumn implements BaseColumns {
        public static final String TABLE_NAME = "user_data";
        public static final String HEADING = "heading";
        public static final String DATA = "data";
        public static final String CREATED_ON = "created_on";
        public static final String LAST_MODIFIED_ON = "last_modified_on";
        public static final String ENCRYPTION_TOKEN = "enc_token";
        public static final String COLOR = "color";
    }
}
    
