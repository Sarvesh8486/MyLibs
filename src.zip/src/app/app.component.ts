import { Component } from '@angular/core';
import { MainPageComponent }  from './main-page/main-page.component';
@Component({
  selector: 'my-app',
  template: `<main-page></main-page>`,
})
export class AppComponent  { name = 'Angular'; }
