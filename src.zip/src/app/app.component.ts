import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app works!';
  minutesform: FormGroup;
  cronExpression = "";

  constructor(private fb: FormBuilder) { }
  ngOnInit() {
    this.minutesform = this.fb.group({
      seconds: new FormControl([0, [Validators.required]]),
      minutes: new FormControl([0, Validators.required])
    });
  }

  minutesSubmit() {
    console.log(this.minutesform.valid);
    const sec = this.minutesform.controls.seconds.value;
    const min = this.minutesform.controls.minutes.value;
    this.cronExpression = '0/' + sec + ' 0/' + min + ' 0 0 0 0';
  }
}
