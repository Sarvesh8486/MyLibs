// imports
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

//components
import { MainPageComponent } from './main-page/main-page.component';
import { ChangeComponent } from './main-page/change.component';
import { ExecutionComponent } from './execution/execution.component';

//pipes
import { TemplateFilterByCloudPipe } from './main-page/main-page-cloud.pipe';

// app Compo
import { AppComponent } from './app.component';

import { SharedService } from './services/shared-services';

@NgModule({

  imports: [BrowserModule,
    FormsModule,
    RouterModule.forRoot([
      { path: 'main-page', component: MainPageComponent },
      { path: 'exe/:template', component: ExecutionComponent },
    ])
  ],
  declarations: [AppComponent,
    MainPageComponent,
    ChangeComponent,
    ExecutionComponent,
    TemplateFilterByCloudPipe,],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent],
  providers:[SharedService],
})
export class AppModule { }
