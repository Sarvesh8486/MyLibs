"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var MainPageComponent = (function () {
    function MainPageComponent() {
        this.templates = [
            { "select": false, "cloud": 'Finance', 'wf': 'Manage User 1', 'desc': 'Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 1' },
            { "select": false, "cloud": 'SCM', 'wf': 'Manage User 2', 'desc': 'Use to manage user 2', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 2' },
            { "select": false, "cloud": 'Finance', 'wf': 'Manage User 3', 'desc': 'Use to manage user 3', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 3' },
            { "select": false, "cloud": 'SCM', 'wf': 'Manage User 4', 'desc': 'Use to manage user 4', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 4' },
            { "select": false, "cloud": 'PPM', 'wf': 'Manage User 5', 'desc': 'Use to manage user 5', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 5' },
        ];
    }
    MainPageComponent.prototype.trackByIndex = function (index, obj) {
        return index;
    };
    return MainPageComponent;
}());
MainPageComponent = __decorate([
    core_1.Component({
        selector: 'main-page',
        templateUrl: './main-page.html'
    }),
    __metadata("design:paramtypes", [])
], MainPageComponent);
exports.MainPageComponent = MainPageComponent;
//# sourceMappingURL=main-page.component.js.map