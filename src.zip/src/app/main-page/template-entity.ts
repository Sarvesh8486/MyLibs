export class Templates {
    select: boolean;
    cloud:string;
    wf:string;
    desc:string;
    excel:string;
    ucm:string;
    job:string;
    param:string;
}