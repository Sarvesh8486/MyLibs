import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import 'rxjs/add/operator/switchMap';
@Component({
    selector: 'execute',
    template: '<p>Hello All...</p>',
})
export class ExecutionComponent implements OnInit {

    constructor(
        private route: ActivatedRoute,
        private router: Router
    ) {}

    ngOnInit() {
        this.route.params.forEach(element => {
            console.log(element);
        });
    }
} 