package com.whiteboard.securenotes.utils;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.whiteboard.securenotes.R;
import com.whiteboard.securenotes.fragments.AddEditNoteFragment;
import com.whiteboard.securenotes.fragments.AllNotesFragment;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class UserListAdapters extends RecyclerView.Adapter<UserListAdapters.UserListAdapterHolders>{

    OnClickHandler handler;

    public interface OnClickHandler {
        void onClick(int id);
    }

    Cursor cursor;
    public UserListAdapters(Cursor cursor, OnClickHandler handler){
        this.cursor = cursor;
        this.handler = handler;
    }

    public void updateCursor(Cursor cursor){
        if(this.cursor!=null)
            this.cursor.close();
        this.cursor = cursor;
        notifyDataSetChanged();
    }

    @Override
    public UserListAdapterHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.rv_layout, parent, false);
        UserListAdapterHolders holder = new UserListAdapterHolders(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(UserListAdapterHolders holder, int position) {
        if(cursor!=null && cursor.moveToPosition(position)){
            holder.title.setText(cursor.getString(0));
            String timeStamp = cursor.getString(1);
            String colorStr = cursor.getString(2);
            int color= new ColorMap(((AllNotesFragment)handler).getContext()).getColorInt(colorStr);
            holder.cardView.setBackgroundColor(color);
            Timestamp ts = null;
            try {
                ts = new Timestamp(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(timeStamp).getTime());
            } catch (ParseException e) {
            }
            String date = new SimpleDateFormat("dd-MMM-yyyy").format(new Date(ts.getTime()));
            String time = new SimpleDateFormat("hh:mm a").format(new Date(ts.getTime()));

            holder.date.setText(date);
            holder.time.setText(time);

        }

    }

    @Override
    public int getItemCount() {
        if(cursor==null)
            return 0;
        return cursor.getCount();
    }

    public class UserListAdapterHolders extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        TextView title, date, time;
        CardView cardView;
        public UserListAdapterHolders(View itemView) {
            super(itemView);
            cardView = (CardView) itemView.findViewById(R.id.linear_layout);
            title = (TextView) itemView.findViewById(R.id.rv_note_title);
            date = (TextView) itemView.findViewById(R.id.rv_date);
            time = (TextView) itemView.findViewById(R.id.rv_time);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            if(cursor!=null && cursor.moveToPosition(adapterPosition)){
                int id = cursor.getInt(3);
                handler.onClick(id);
            }
        }
    }

}
    
