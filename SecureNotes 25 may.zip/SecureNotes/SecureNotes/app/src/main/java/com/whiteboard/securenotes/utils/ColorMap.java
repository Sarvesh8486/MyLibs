package com.whiteboard.securenotes.utils;

import android.content.Context;

import com.whiteboard.securenotes.R;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Stark on 14/05/2017.
 */

public class ColorMap {
    Map<String, Integer> map;
    public ColorMap(Context context){
        map = new HashMap<>();
        map.put("brick", context.getResources().getColor(R.color.note_color_brick));
        map.put("grey", context.getResources().getColor(R.color.note_color_grey));
        map.put("green", context.getResources().getColor(R.color.note_color_green));
        map.put("skin", context.getResources().getColor(R.color.note_color_skin));
        map.put("white", context.getResources().getColor(R.color.note_color_white));
        map.put("yellow", context.getResources().getColor(R.color.note_color_yellow));


    }

    public int getColorInt(String color){
        return map.get(color);
    }
}
