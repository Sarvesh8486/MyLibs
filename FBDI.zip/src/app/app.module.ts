// imports
import { NgModule , CUSTOM_ELEMENTS_SCHEMA  }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';


//components
import { MainPageComponent }  from './main-page/main-page.component';
import { ChangeComponent }  from './main-page/change.component';

//pipes
import { TemplateFilterByCloudPipe }  from './main-page/main-page-cloud.pipe';

// app Compo
import { AppComponent }  from './app.component';

@NgModule({
  imports:      [ BrowserModule,
                  FormsModule, ],
  declarations: [ AppComponent,
                  MainPageComponent,
                  ChangeComponent,
                  TemplateFilterByCloudPipe, ],
                  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
