import { Component, OnChanges, SimpleChanges, Input } from '@angular/core';
import { Templates } from './template-entity';

@Component({
    selector: 'main-page',
    templateUrl: './main-page.html'

})
export class MainPageComponent {
    cloudSearch: string;
    selected: boolean;
    templates: Array<Templates>;

    trackByIndex(index: number, obj: any): any {
        return index;
    }

    constructor() {
        this.templates = [
            { "select": false, "cloud": 'Finance', 'wf': 'Manage User 1', 'desc': 'Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1 Use to manage user 1', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 1' },
            { "select": false, "cloud": 'SCM', 'wf': 'Manage User 2', 'desc': 'Use to manage user 2', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 2' },
            { "select": false, "cloud": 'Finance', 'wf': 'Manage User 3', 'desc': 'Use to manage user 3', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 3' },
            { "select": false, "cloud": 'SCM', 'wf': 'Manage User 4', 'desc': 'Use to manage user 4', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 4' },
            { "select": false, "cloud": 'PPM', 'wf': 'Manage User 5', 'desc': 'Use to manage user 5', 'excel': '', 'ucm': '', 'job': 'ABC', 'param': 'DEF 5' },
        ];

    }

}