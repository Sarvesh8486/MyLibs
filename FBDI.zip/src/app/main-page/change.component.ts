import { Component, OnChanges, SimpleChanges, Input, DoCheck, KeyValueDiffers, OnInit } from '@angular/core';
import { Templates } from './template-entity';

@Component({
    selector: 'change-template',
    templateUrl: './change.html',

})
export class ChangeComponent implements OnChanges {
    @Input() username: string;
    @Input() password: string;
    @Input() url: string;
    @Input() template: Templates[];
    visible: boolean;

    ngOnChanges(changes: SimpleChanges) {
        this.validateButton();
    }

    validateTemplate():boolean {
        console.log(this.template);
        this.template.forEach(element => {
             if(element['select']){
                 return true;
             }
        });
        return false;
    }

    validateButton() {
        var flag = this.validateTemplate();
        console.log(flag);
        if (this.username != undefined && this.username.trim().length != 0 &&
            this.password != undefined && this.password.trim().length != 0 &&
            this.url != undefined && this.url.trim().length != 0 &&
            flag) {
            this.visible = true;
        } else {
            this.visible = false;
        }
    }
}